package Test2::Util::Table::Cell;
use strict;
use warnings;

our $VERSION = '0.000162';

use base 'Term::Table::Cell';

1;
